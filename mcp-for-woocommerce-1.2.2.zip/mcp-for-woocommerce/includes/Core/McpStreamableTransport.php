<?php
/**
 * The WordPress MCP Streamable HTTP Transport class.
 *
 * @package WordPressMcp
 */



namespace McpForWoo\Core;

use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use Exception;

/**
 * The WordPress MCP Streamable HTTP Transport class.
 * Uses JSON-RPC 2.0 format for direct streamable connections.
 */
class McpStreamableTransport extends McpTransportBase {

	/**
	 * The request ID.
	 *
	 * @var int
	 */
	private int $request_id = 0;

	/**
	 * Initialize the class and register routes
	 *
	 * @param WpMcp $mcp The WordPress MCP instance.
	 */
	public function __construct( WpMcp $mcp ) {
		parent::__construct( $mcp );
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
		add_filter( 'rest_pre_serve_request', array( $this, 'handle_cors_preflight' ), 10, 4 );
	}

	/**
	 * Register all MCP proxy routes
	 */
	public function register_routes(): void {
		// If MCP is disabled, don't register routes.
		if ( ! $this->is_mcp_enabled() ) {
			return;
		}

		// Single endpoint for all MCP operations.
		register_rest_route(
			'wp/v2',
			'/wpmcp/streamable',
			array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => array( $this, 'handle_request' ),
				'permission_callback' => array( $this, 'check_permission' ),
			)
		);


		// OpenAPI spec endpoint
		register_rest_route(
			'wp/v2',
			'/wpmcp/openapi.json',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'openapi_spec' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * Check if the user has permission to access the MCP API
	 *
	 * @return bool|WP_Error
	 */
	public function check_permission(): WP_Error|bool {
		try {
			
			// If MCP is disabled, deny access.
			if ( ! $this->is_mcp_enabled() ) {
				return new WP_Error(
					'mcp_disabled',
					'MCP functionality is currently disabled.',
					array( 'status' => 403 )
				);
			}
			
			// Check JWT required setting
			$jwt_required = function_exists( 'get_option' ) ? (bool) get_option( 'mcpfowo_jwt_required', true ) : true;
			
			
			if ( ! $jwt_required ) {
				// JWT is disabled, allow access without authentication (readonly mode)
				return true;
			}
			
			// JWT is required, check if user is authenticated via JWT or cookies
			// The JWT authentication is handled by the rest_authentication_errors filter
			// which runs before permission callbacks
			$result = is_user_logged_in();
			
			if ( ! $result ) {
				return new WP_Error(
					'rest_forbidden',
					'You do not have permission to access this endpoint.',
					array( 'status' => 403 )
				);
			}
			
			return $result;
			
		} catch ( Exception $e ) {
			return new WP_Error(
				'permission_check_error',
				'Error checking permissions: ' . $e->getMessage(),
				array( 'status' => 500 )
			);
		}
	}

	/**
	 * Handle the HTTP request with true streaming support
	 *
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function handle_request( WP_REST_Request $request ) {
		
		// Handle preflight requests
		if ( 'OPTIONS' === $request->get_method() ) {
			$this->stream_response( null, 204 );
			return;
		}

		$method = $request->get_method();

		if ( 'POST' === $method ) {
			$this->handle_streamable_post_request( $request );
			return;
		}

		// Health-check with streaming support
		if ( 'GET' === $method ) {
			$accept = $request->get_header( 'accept' );
			
			// For streamable transport, require proper Accept header
			if ( ! $this->validate_streamable_headers( $request ) ) {
				$this->stream_error_response(
					McpErrorHandler::invalid_accept_header( 0 ),
					400
				);
				return;
			}
			
			// Stream health response
			$body = array(
				'jsonrpc' => '2.0',
				'result'  => array(
					'status'    => 'ok',
					'transport' => 'streamable-http',
					'endpoint'  => '/wp/v2/wpmcp/streamable',
					'streaming' => true,
				),
			);
			$this->stream_response( $body, 200 );
			return;
		}

		if ( 'HEAD' === $method ) {
			$this->stream_response( null, 200, array(
				'MCP-Protocol-Version' => '2025-06-18',
				'X-Transport-Type' => 'streamable-http'
			) );
			return;
		}

		// Return 405 for unsupported methods
		$this->stream_error_response(
			McpErrorHandler::create_error_response( 0, McpErrorHandler::INVALID_REQUEST, 'Method not allowed' ),
			405
		);
	}

	/**
	 * Validate streamable headers according to MCP specification
	 *
	 * @param WP_REST_Request $request The request object.
	 * @return bool
	 */
	private function validate_streamable_headers( WP_REST_Request $request ): bool {
		$accept_header = $request->get_header( 'accept' );
		
		if ( ! $accept_header ) {
			return false;
		}
		
		// Require both application/json and text/event-stream for streamable transport
		return strpos( $accept_header, 'application/json' ) !== false &&
		       strpos( $accept_header, 'text/event-stream' ) !== false;
	}

	/**
	 * Stream response directly to client with chunked encoding
	 *
	 * @param mixed $data Response data.
	 * @param int   $status HTTP status code.
	 * @param array $headers Additional headers.
	 */
	private function stream_response( $data = null, int $status = 200, array $headers = array() ) {
		// Disable WordPress output buffering
		if ( ob_get_level() ) {
			ob_end_clean();
		}
		
		// Set status code
		http_response_code( $status );
		
		// Set streaming headers
		header( 'Content-Type: application/json' );
		header( 'Transfer-Encoding: chunked' );
		header( 'Connection: keep-alive' );
		header( 'Cache-Control: no-cache' );
		header( 'MCP-Protocol-Version: 2025-06-18' );
		header( 'X-Transport-Type: streamable-http' );
		
		// Add custom headers
		foreach ( $headers as $key => $value ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- HTTP headers, values are controlled by application
			header( sanitize_key( $key ) . ': ' . sanitize_text_field( $value ) );
		}
		
		// Stream the response
		if ( $data !== null ) {
			$json = wp_json_encode( $data, JSON_UNESCAPED_SLASHES );
			$this->write_chunk( $json );
		}
		
		// End the stream
		$this->write_chunk( '' ); // Final chunk
		flush();
		exit;
	}

	/**
	 * Stream error response
	 *
	 * @param array $error Error data.
	 * @param int   $status HTTP status code.
	 */
	private function stream_error_response( array $error, int $status = 400 ) {
		$this->stream_response( $error, $status );
	}

	/**
	 * Write chunked data to stream
	 *
	 * @param string $data Data to write.
	 */
	private function write_chunk( string $data ) {
		$length = strlen( $data );
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- HTTP chunked transfer encoding protocol
		echo dechex( $length ) . "\r\n";
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- HTTP chunked transfer encoding protocol
		echo $data . "\r\n";
		flush();
	}

	/**
	 * Handle streamable POST requests
	 *
	 * @param WP_REST_Request $request The request object.
	 */
	private function handle_streamable_post_request( WP_REST_Request $request ) {
		try {
			// Log incoming request for Claude.ai debugging
			$this->log_claude_request( $request );
			
			// Validate streamable headers - REQUIRED for streamable transport
			if ( ! $this->validate_streamable_headers( $request ) ) {
				$this->stream_error_response(
					McpErrorHandler::invalid_accept_header( 0 ),
					400
				);
				return;
			}
			
			// Check if JWT is disabled - if so, use PHP proxy mode for external access
			$jwt_required = function_exists( 'get_option' ) ? (bool) get_option( 'mcpfowo_jwt_required', true ) : true;
			if ( ! $jwt_required ) {
				$this->handle_streamable_proxy_mode( $request );
				return;
			}

			// Check for Claude.ai beta header requirement
			$beta_header = $request->get_header( 'anthropic-beta' );

			// Validate content type - be more flexible with content-type headers
			$content_type = $request->get_header( 'content-type' );
			if ( $content_type && strpos( $content_type, 'application/json' ) === false ) {
				$this->stream_error_response(
					McpErrorHandler::invalid_content_type( 0 ),
					400
				);
				return;
			}

			// Get the JSON-RPC message(s) - can be single message or array batch
			$body = $request->get_json_params();
			if ( null === $body ) {
				$this->stream_error_response(
					McpErrorHandler::parse_error( 0, 'Invalid JSON in request body' ),
					400
				);
				return;
			}

			// Handle both single messages and batched arrays
			$messages                       = is_array( $body ) && isset( $body[0] ) ? $body : array( $body );
			$has_requests                   = false;
			$has_notifications_or_responses = false;

			// Validate all messages and categorize them
			foreach ( $messages as $message ) {
				$validation_result = McpErrorHandler::validate_jsonrpc_message( $message );
				if ( true !== $validation_result ) {
					McpErrorHandler::log_error( 
						'JSON-RPC validation failed for incoming message', 
						array( 
							'message' => $message, 
							'validation_error' => $validation_result 
						) 
					);
					$this->stream_error_response( $validation_result, 400 );
					return;
				}

				// Check if it's a request (has id and method) or notification/response
				if ( isset( $message['method'] ) && isset( $message['id'] ) ) {
					$has_requests = true;
				} else {
					$has_notifications_or_responses = true;
				}
			}

			// If only notifications or responses, return 202 Accepted with no body
			if ( $has_notifications_or_responses && ! $has_requests ) {
				$this->stream_response( null, 202 );
				return;
			}

			// Process requests with streaming support
			$results        = array();
			$has_initialize = false;
			$is_large_batch = count( $messages ) > 5; // Stream for large batches
			
			if ( $is_large_batch ) {
				// Start streaming response for large batches
				$this->start_batch_stream();
			}
			
			foreach ( $messages as $index => $message ) {
				if ( isset( $message['method'] ) && isset( $message['id'] ) ) {
					$this->request_id = (int) $message['id'];
					if ( 'initialize' === $message['method'] ) {
						$has_initialize = true;
					}
					
					$result = $this->process_message( $message );
					
					if ( $is_large_batch ) {
						// Stream each result immediately for large batches
						$this->stream_batch_item( $result, $index );
					} else {
						$results[] = $result;
					}
				}
			}
			
			if ( $is_large_batch ) {
				// End batch stream
				$this->end_batch_stream( $has_initialize );
				return;
			}

			// Return single result or small batch
			$response_body = count( $results ) === 1 ? $results[0] : $results;

			// Log outgoing response for Claude.ai debugging
			$this->log_claude_response( $response_body );

			// Validate outgoing response
			if ( is_array( $response_body ) ) {
				$responses_to_validate = isset( $response_body[0] ) ? $response_body : array( $response_body );
				foreach ( $responses_to_validate as $response ) {
					$validation_result = McpErrorHandler::validate_jsonrpc_message( $response );
					if ( true !== $validation_result ) {
						McpErrorHandler::log_error( 
							'Invalid JSON-RPC response being sent', 
							array( 
								'response' => $response,
								'validation_error' => $validation_result
							) 
						);
					}
				}
			}

				$headers = array();

				// If this batch included initialize, assign a session ID per spec (optional for clients)
				if ( $has_initialize ) {
					if ( function_exists( 'wp_generate_uuid4' ) ) {
						$headers['Mcp-Session-Id'] = wp_generate_uuid4();
					} else {
						$headers['Mcp-Session-Id'] = bin2hex( random_bytes( 16 ) );
					}
				}

				// Stream the response
				$this->stream_response( $response_body, 200, $headers );
		} catch ( \Throwable $exception ) {
			// Handle any unexpected exceptions
			McpErrorHandler::log_error( 'Unexpected error in handle_streamable_post_request', array( 'exception' => $exception->getMessage() ) );
			$this->stream_error_response(
				McpErrorHandler::handle_exception( $exception, $this->request_id ),
				500
			);
		}
	}

	/**
	 * Process a JSON-RPC message
	 *
	 * @param array $message The JSON-RPC message.
	 * @return array
	 */
	private function process_message( array $message ): array {
		$this->request_id = (int) $message['id'];
		$params           = $message['params'] ?? array();

		// Route the request using the base class
		$result = $this->route_request( $message['method'], $params, $this->request_id );

		// Check if the result contains an error
		if ( isset( $result['error'] ) ) {
			return $this->format_error_response( $result, $this->request_id );
		}

		return $this->format_success_response( $result, $this->request_id );
	}

	/**
	 * Create a method not found error (JSON-RPC 2.0 format)
	 *
	 * @param string $method The method that was not found.
	 * @param int    $request_id The request ID.
	 * @return array
	 */
	protected function create_method_not_found_error( string $method, int $request_id ): array {
		$error_response = McpErrorHandler::method_not_found( $request_id, $method );
		return array(
			'error' => $error_response['error'],
		);
	}

	/**
	 * Handle exceptions that occur during request processing (JSON-RPC 2.0 format)
	 *
	 * @param \Throwable $exception The exception.
	 * @param int        $request_id The request ID.
	 * @return array
	 */
	protected function handle_exception( \Throwable $exception, int $request_id ): array {
		$error_response = McpErrorHandler::handle_exception( $exception, $request_id );
		return array(
			'error' => $error_response['error'],
		);
	}

	/**
	 * Format a successful response (JSON-RPC 2.0 format)
	 *
	 * @param array $result The result data.
	 * @param int   $request_id The request ID.
	 * @return array
	 */
	protected function format_success_response( array $result, int $request_id = 0 ): array {
		$response = array(
			'jsonrpc' => '2.0',
			'id'      => $request_id,
			'result'  => $result,
		);

		return $response;
	}

	/**
	 * Format an error response (JSON-RPC 2.0 format)
	 *
	 * @param array $error The error data.
	 * @param int   $request_id The request ID.
	 * @return array
	 */
	protected function format_error_response( array $error, int $request_id = 0 ): array {
		// If the error already contains a proper error structure
		if ( isset( $error['error'] ) && is_array( $error['error'] ) ) {
			$response = array(
				'jsonrpc' => '2.0',
				'id'      => $request_id,
				'error'   => $error['error'],
			);
			
			// Validate the error structure has required fields
			if ( ! isset( $error['error']['code'] ) || ! isset( $error['error']['message'] ) ) {
				McpErrorHandler::log_error( 
					'Error response missing required fields', 
					array( 'error' => $error['error'] ) 
				);
				return McpErrorHandler::internal_error( $request_id, 'Invalid error response format' );
			}
			
			return $response;
		}

		// Log the invalid error format for debugging
		McpErrorHandler::log_error( 
			'Invalid error response format received', 
			array( 'error' => $error ) 
		);
		
		// If it's not already a proper error response, make it one
		return McpErrorHandler::internal_error( $request_id, 'Invalid error response format' );
	}

	/**
	 * Handle CORS preflight requests for MCP endpoint.
	 *
	 * @param mixed           $served  Whether the request has been served.
	 * @param WP_REST_Response $result  The response object.
	 * @param WP_REST_Request $request The request object.
	 * @param WP_REST_Server  $server  The REST server instance.
	 * @return mixed
	 */
	public function handle_cors_preflight( $served, $result, $request, $server ) {
		
		// Only handle our MCP endpoint
		if ( strpos( $request->get_route(), '/wpmcp/streamable' ) === false ) {
			return $served;
		}

		
		// Set CORS headers for all requests to our endpoint - allow all domains with Claude.ai specific headers
		header( 'Access-Control-Allow-Origin: *' );
		header( 'Access-Control-Allow-Methods: GET, POST, OPTIONS, HEAD' );
		header( 'Access-Control-Allow-Headers: content-type, accept, anthropic-beta, authorization, mcp-protocol-version, mcp-session-id, user-agent, cache-control, pragma' );
		header( 'Access-Control-Expose-Headers: MCP-Protocol-Version, Mcp-Session-Id' );
		header( 'Access-Control-Max-Age: 1800' );
		header( 'Access-Control-Allow-Credentials: false' );

		// Handle OPTIONS preflight request
		if ( $request->get_method() === 'OPTIONS' ) {
			http_response_code( 204 );
			exit;
		}

		return $served;
	}

	/**
	 * Start streaming response for large batches
	 */
	private function start_batch_stream() {
		// Disable WordPress output buffering
		if ( ob_get_level() ) {
			ob_end_clean();
		}
		
		// Set status code
		http_response_code( 200 );
		
		// Set streaming headers
		header( 'Content-Type: application/json' );
		header( 'Transfer-Encoding: chunked' );
		header( 'Connection: keep-alive' );
		header( 'Cache-Control: no-cache' );
		header( 'MCP-Protocol-Version: 2025-06-18' );
		header( 'X-Transport-Type: streamable-http' );
		
		// Start JSON array for batch response
		$this->write_chunk( '[' );
	}

	/**
	 * Stream a single item in a batch
	 *
	 * @param array $item The response item.
	 * @param int   $index The item index.
	 */
	private function stream_batch_item( array $item, int $index ) {
		$json = wp_json_encode( $item, JSON_UNESCAPED_SLASHES );
		
		// Add comma separator for items after the first
		if ( $index > 0 ) {
			$this->write_chunk( ',' );
		}
		
		$this->write_chunk( $json );
	}

	/**
	 * End streaming response for large batches
	 *
	 * @param bool $has_initialize Whether initialize was called.
	 */
	private function end_batch_stream( bool $has_initialize = false ) {
		// Close JSON array
		$this->write_chunk( ']' );
		
		// Add session ID header if initialize was called
		if ( $has_initialize ) {
			if ( function_exists( 'wp_generate_uuid4' ) ) {
				header( 'Mcp-Session-Id: ' . wp_generate_uuid4() );
			} else {
				header( 'Mcp-Session-Id: ' . bin2hex( random_bytes( 16 ) ) );
			}
		}
		
		// End the stream
		$this->write_chunk( '' ); // Final chunk
		flush();
		exit;
	}

	/**
	 * Handle streamable PHP proxy mode when JWT is disabled
	 *
	 * @param WP_REST_Request $request The request object.
	 */
	private function handle_streamable_proxy_mode( WP_REST_Request $request ) {
		
		// Get the request body
		$body = $request->get_body();
		
		if ( empty( $body ) ) {
			$this->stream_error_response(
				array(
					'jsonrpc' => '2.0',
					'id' => null,
					'error' => array(
						'code' => -32700,
						'message' => 'Parse error: Empty request body'
					)
				),
				400
			);
			return;
		}

		// Decode JSON request
		$data = json_decode( $body, true );
		if ( json_last_error() !== JSON_ERROR_NONE ) {
			$this->stream_error_response(
				array(
					'jsonrpc' => '2.0',
					'id' => null,
					'error' => array(
						'code' => -32700,
						'message' => 'Parse error: ' . json_last_error_msg()
					)
				),
				400
			);
			return;
		}

		$id = $data['id'] ?? null;

		// Process the MCP request internally
		try {
			$method = $data['method'] ?? '';
			$params = $data['params'] ?? array();

			// Route the request using existing MCP routing
			$result = $this->route_request( $method, $params, (int) $id );

			// Format response according to JSON-RPC 2.0 and stream it
			if ( isset( $result['error'] ) ) {
				// Ensure error code is integer for Claude Desktop compatibility
				$error = $result['error'];
				if ( isset( $error['code'] ) && ! is_int( $error['code'] ) ) {
					$error['code'] = (int) $error['code'];
				}
				$error_response = array(
					'jsonrpc' => '2.0',
					'id' => $id,
					'error' => $error
				);
				
				// Log error response from streamable proxy mode
				$this->log_claude_response( $error_response );
				
				$this->stream_response( $error_response, 200 );
			} else {
				$response_body = array(
					'jsonrpc' => '2.0',
					'id' => $id,
					'result' => $result
				);
				
				// Log response from streamable proxy mode
				$this->log_claude_response( $response_body );
				
				$this->stream_response( $response_body, 200 );
			}
		} catch ( Exception $e ) {
			$exception_response = array(
				'jsonrpc' => '2.0',
				'id' => $id,
				'error' => array(
					'code' => -32603,
					'message' => 'Internal error: ' . $e->getMessage()
				)
			);
			
			// Log exception response from streamable proxy mode
			$this->log_claude_response( $exception_response );
			
			$this->stream_error_response( $exception_response, 500 );
		}
	}

	/**
	 * Log incoming Claude.ai request for debugging
	 *
	 * @param WP_REST_Request $request The request object.
	 */
	private function log_claude_request( $request ) {
		$headers = $request->get_headers();
		$body = $request->get_body();
		$params = $request->get_params();
		$method = $request->get_method();
		$url = $request->get_route();
		
		$user_agent = $headers['user_agent'][0] ?? '';
		$accept = $headers['accept'][0] ?? '';
		$content_type = $headers['content_type'][0] ?? '';
		$anthropic_beta = $headers['anthropic_beta'][0] ?? '';
		$authorization = !empty($headers['authorization']) ? '[PRESENT]' : '[MISSING]';
		
		// Detect connection source based on user agent and other indicators
		$connection_source = $this->detect_connection_source($headers);
		
		$log_data = array(
			'timestamp' => current_time('mysql'),
			'connection_source' => $connection_source,
			'method' => $method,
			'url' => $url,
			'user_agent' => $user_agent,
			'accept' => $accept,
			'content_type' => $content_type,
			'anthropic_beta' => $anthropic_beta,
			'authorization' => $authorization,
			'body_length' => strlen($body),
			'body' => $body,
			'params' => $params,
			'remote_addr' => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '',
			'referer' => isset( $_SERVER['HTTP_REFERER'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : '',
			'all_headers' => $headers
		);
		
		// Enhanced connection attempt logging
		$this->log_connection_attempt($log_data);
		
		
	}

	/**
	 * Log outgoing response for Claude.ai debugging
	 *
	 * @param mixed $response_body The response body.
	 */
	private function log_claude_response( $response_body ) {
		$log_data = array(
			'timestamp' => current_time('mysql'),
			'response_type' => gettype($response_body),
			'response_body' => $response_body,
			'success' => !isset($response_body['error']),
			'error_code' => isset($response_body['error']['code']) ? $response_body['error']['code'] : null,
			'error_message' => isset($response_body['error']['message']) ? $response_body['error']['message'] : null
		);
		
		// Enhanced connection result logging
		$this->log_connection_result($log_data);
		
		
	}

	/**
	 * Detect connection source based on headers and other indicators
	 *
	 * @param array $headers Request headers.
	 * @return string
	 */
	private function detect_connection_source( $headers ) {
		$user_agent = $headers['user_agent'][0] ?? '';
		$anthropic_beta = $headers['anthropic_beta'][0] ?? '';
		$referer = isset( $_SERVER['HTTP_REFERER'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : '';
		
		// Claude.ai web app detection
		if ( strpos( $user_agent, 'claude' ) !== false || 
			 strpos( $user_agent, 'Claude' ) !== false ||
			 strpos( $referer, 'claude.ai' ) !== false ||
			 !empty( $anthropic_beta ) ) {
			return 'claude.ai-webapp';
		}
		
		// Claude Desktop detection
		if ( strpos( $user_agent, 'Claude Desktop' ) !== false ||
			 strpos( $user_agent, 'claude-desktop' ) !== false ) {
			return 'claude-desktop';
		}
		
		// MCP proxy detection
		if ( strpos( $user_agent, 'mcp' ) !== false ||
			 strpos( $user_agent, 'MCP' ) !== false ) {
			return 'mcp-proxy';
		}
		
		// Generic HTTP client detection
		if ( strpos( $user_agent, 'curl' ) !== false ) {
			return 'curl';
		}
		
		if ( strpos( $user_agent, 'Postman' ) !== false ) {
			return 'postman';
		}
		
		if ( empty( $user_agent ) ) {
			return 'unknown-no-ua';
		}
		
		return 'unknown-' . substr( $user_agent, 0, 20 );
	}
	
	/**
	 * Log connection attempt with enhanced details
	 *
	 * @param array $log_data Connection log data.
	 */
	private function log_connection_attempt( $log_data ) {
		$connection_log = array(
			'event' => 'connection_attempt',
			'timestamp' => current_time('mysql'),
			'source' => $log_data['connection_source'],
			'method' => $log_data['method'],
			'remote_addr' => $log_data['remote_addr'],
			'user_agent' => $log_data['user_agent'],
			'endpoint' => 'https://woo.webtalkbot.com' . $log_data['url'],
			'has_auth' => $log_data['authorization'] === '[PRESENT]',
			'anthropic_beta' => $log_data['anthropic_beta'],
			'request_size' => $log_data['body_length']
		);
		
		
	}
	
	/**
	 * Log connection result with success/failure details
	 *
	 * @param array $log_data Response log data.
	 */
	private function log_connection_result( $log_data ) {
		$result_log = array(
			'event' => 'connection_result',
			'timestamp' => current_time('mysql'),
			'success' => $log_data['success'],
			'error_code' => $log_data['error_code'],
			'error_message' => $log_data['error_message'],
			'response_type' => $log_data['response_type']
		);
		
		
	}


	/**
	 * Generate OpenAPI specification for MCP tools
	 *
	 * @return WP_REST_Response
	 */
	public function openapi_spec() {
		$site_url = get_site_url();
		$spec = array(
			'openapi' => '3.0.1',
			'info' => array(
				'title' => 'WooCommerce MCP API',
				'description' => 'Model Context Protocol (MCP) integration for WooCommerce stores',
				'version' => MCPFOWO_VERSION,
				'contact' => array(
					'email' => get_option( 'admin_email', 'admin@' . wp_parse_url( $site_url, PHP_URL_HOST ) )
				)
			),
			'servers' => array(
				array(
					'url' => $site_url,
					'description' => 'WooCommerce MCP Server'
				)
			),
			'paths' => array(
				'/wp-json/wp/v2/wpmcp/streamable' => array(
					'post' => array(
						'operationId' => 'mcpJsonRpcCall',
						'summary' => 'MCP JSON-RPC endpoint for advanced queries',
						'description' => 'Advanced Model Context Protocol endpoint using JSON-RPC 2.0. Use this for complex WooCommerce operations like detailed product searches, order management, and data analysis.',
						'requestBody' => array(
							'required' => true,
							'content' => array(
								'application/json' => array(
									'schema' => array(
										'$ref' => '#/components/schemas/JsonRpcRequest'
									)
								)
							)
						),
						'responses' => array(
							'200' => array(
								'description' => 'Successful response',
								'content' => array(
									'application/json' => array(
										'schema' => array(
											'$ref' => '#/components/schemas/JsonRpcResponse'
										)
									)
								)
							)
						)
					),
					'get' => array(
						'operationId' => 'searchWooCommerce',
						'summary' => 'Search WooCommerce store data',
						'description' => 'Use this tool to search for information in the WooCommerce store. Perfect for queries about products, order status, or customers. Example queries: \'find all orders for email john.doe@example.com\', \'what products are in the electronics category?\', \'show product details for ID 123\', \'search for laptop products\', \'get recent orders\'.',
						'parameters' => array(
							array(
								'name' => 'query',
								'in' => 'query',
								'description' => 'Specific search query. Examples: \'latest orders\', \'products under $50\', \'customer John Smith\', \'laptops in stock\', \'orders from last week\'.',
								'required' => true,
								'schema' => array(
									'type' => 'string'
								)
							)
						),
						'responses' => array(
							'200' => array(
								'description' => 'Successful response with found data.',
								'content' => array(
									'application/json' => array(
										'schema' => array(
											'type' => 'object',
											'properties' => array(
												'status' => array( 'type' => 'string' ),
												'transport' => array( 'type' => 'string' ),
												'endpoint' => array( 'type' => 'string' )
											)
										)
									)
								)
							)
						)
					)
				)
			),
			'components' => array(
				'schemas' => array(
					'JsonRpcRequest' => array(
						'type' => 'object',
						'required' => array( 'jsonrpc', 'method', 'id' ),
						'properties' => array(
							'jsonrpc' => array( 'type' => 'string', 'enum' => array( '2.0' ) ),
							'method' => array( 'type' => 'string' ),
							'params' => array( 'type' => 'object' ),
							'id' => array( 'oneOf' => array(
								array( 'type' => 'string' ),
								array( 'type' => 'integer' ),
								array( 'type' => 'null' )
							) )
						)
					),
					'JsonRpcResponse' => array(
						'type' => 'object',
						'required' => array( 'jsonrpc', 'id' ),
						'properties' => array(
							'jsonrpc' => array( 'type' => 'string', 'enum' => array( '2.0' ) ),
							'result' => array( 'type' => 'object' ),
							'error' => array(
								'type' => 'object',
								'properties' => array(
									'code' => array( 'type' => 'integer' ),
									'message' => array( 'type' => 'string' ),
									'data' => array( 'type' => 'object' )
								)
							),
							'id' => array( 'oneOf' => array(
								array( 'type' => 'string' ),
								array( 'type' => 'integer' ),
								array( 'type' => 'null' )
							) )
						)
					)
				)
			)
		);

		return new WP_REST_Response( $spec, 200, array(
			'Content-Type' => 'application/json',
			'Access-Control-Allow-Origin' => '*',
		) );
	}

}
